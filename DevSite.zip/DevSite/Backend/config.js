const dotenv=require('dotenv')
const mongoose=require('mongoose')
dotenv.config()

const connectToMongo = ()=>{

     const mongoUrl=process.env.MONGO_URL
     mongoose.set('strictQuery', false)
      mongoose.connect(mongoUrl ).then((res) => {
      //if succeded do this block of code
      console.log('Connect to DB success',process.env.MONGO_URL)
    }).catch((err) => {
      //catch error
      console.log("Error in DB",err)
    });

}

module.exports=connectToMongo;